create procedure NewProc()
  BEGIN
	#Routine body goes here...
	declare uu varchar(20);
	declare done int default false;
	
	declare cur CURSOR for select user from mysql.user;
	
	declare continue handler for not found set done=true;
	
	open cur;
	
	read_loop:loop
			fetch cur into uu;
			
			select uu;
			
			
			if done then
					leave read_loop;
			end if;
	end loop;
	close cur;
END;

