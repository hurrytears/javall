create procedure delete_match(IN say varchar(10))
  begin
-- 	declare id int(11) default 1;
	declare name varchar(44) default 'Tom';
	declare done int default 0;
-- 	set name='zhangxudong';
-- 	select 100%3 into @batch;
-- 	if id<2 then
-- 		select id, name, @batch, say,course.* from course where cid=id;
-- 	end if
	declare student_cur cursor for select sname from student;
-- 	DECLARE CONTINUE HANDLER FOR NOT FOUND SET done=1;
	declare continue handler for not found set done=1;
	
	open student_cur;
	readloop:loop
		fetch student_cur into name;
		if done=1 then
			leave readloop;
		end if;
		
		select name;
	end loop;
-- 	while done=0 do
-- 		fetch student_cur into name;
-- 		select name;
-- 	end while;
	close student_cur;
end;

